#!/bin/env python3

import _cotangent

print(_cotangent.__file__)
print(_cotangent.__dict__)

print(_cotangent.RenderAndSanitize("a", 1))
