char* render_and_sanitize(char* src);
